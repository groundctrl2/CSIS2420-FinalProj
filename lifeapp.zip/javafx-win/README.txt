The 'bin' directory is part of the OpenJFX SDK for Windows and contains the platform-specific bindings required for the javafx.graphics module to run on Windows. Do not delete. 

In fact, it requires this specific structure where the (modular) jar file for javafx.graphics searches one directory above for a 'bin' folder to look for the the necessary .dll files. 

The 'lib' folder name, however, is arbitrary, but it is the exact folder that must be directly specificed on the '--module-path' in order to include the javafx modules. 