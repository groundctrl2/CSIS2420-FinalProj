For simplicity, double-click or run the 'lifeapp.bat' batch file (on windows) or the 'lifeapp.command' script (on mac) to automatically launch the program. 

--------
Details
--------

Requirements:
	- Java 21+
	- Java FX 21+
	- algs4_modular.jar

Both FX and (a modular version of) algs4 are included. 
 
In order to run the application, all of lifeapp.jar and its (modular) jar dependencies must be placed on the MODULE path using the VM argument --module-path (or -p). 

In this directory, on windows, you may run:

	java --module-path .;javafx-win/lib --module lifeapp

or (shorter): 

	java -p .;javafx-win/lib -m lifeapp

This assumes that the required javafx libaries are in 'javafx-win/lib' AND the required windows-specific .dll files are in 'javafx-win/bin'.

On Mac: 
	java -p .:javafx-mac/lib -m lifeapp

assumes the the required javafx jars are in 'javafx-mac/lib' AND that required mac-specific .dylib files are in that same folder. 

...

All of the above also assumes that the current directory contains 'algs4_modular.jar' and 'lifeapp.jar'. 

You may run the lifeapp module from any other location as long as the module path points to directories containing:

	1) lifeapp.jar 
	2) algs4_modular.jar
	3) the JavaFX modules (with the platform-specific bindings in the appropriate relative, platform-specific locations) 
